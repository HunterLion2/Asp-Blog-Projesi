namespace BlogUygulaması.Models;
public class KonularModel
{
    public int Id { get; set; }
    public string Konu { get; set; } = null!;
}