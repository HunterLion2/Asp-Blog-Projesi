﻿// Yorum Bölümü

const yorum = document.querySelector(".yorumselection");

function AnimasionAdd() {
    yorum.classList.add("animate__fadeInUp");
}

yorum.addEventListener("click", AnimasionAdd);


