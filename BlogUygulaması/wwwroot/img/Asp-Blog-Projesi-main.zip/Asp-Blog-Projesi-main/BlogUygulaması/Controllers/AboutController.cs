using Microsoft.AspNetCore.Mvc;

namespace BlogUygulaması.Controllers;

public class About : Controller
{

    public ActionResult Index()
    {
        return View();
    }

}

